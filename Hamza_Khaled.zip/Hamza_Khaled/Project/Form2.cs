﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 patient = new Form2();
            patient.Show();

        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            this.Close();
            Appointment appointment = new Appointment();
            appointment.Show();
        }

        private void btnDr_Click(object sender, EventArgs e)
        {
            this.Close();
            doctor dr = new doctor();
            dr.Show();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            this.Close();
            PatientInfo patientInfo = new PatientInfo();
            patientInfo.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            using (SqlConnection conn = new SqlConnection(connString))
            {
                SqlCommand command;
                string query = "INSERT INTO patient (patient_name, patient_gender, patient_PhoneNumber, adress) VALUES (@Value1, @Value2, @Value4, @Value5)";
                command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Value1", txtPatientName.Text);
                command.Parameters.AddWithValue("@Value2", comboBoxGender.Text);
                command.Parameters.AddWithValue("@Value4", txtNumber.Text);
                command.Parameters.AddWithValue("@Value5", txtboxAdress.Text);
                if (string.IsNullOrEmpty(txtPatientName.Text) || string.IsNullOrEmpty(comboBoxGender.Text) || string.IsNullOrEmpty(txtNumber.Text) || string.IsNullOrEmpty(txtboxAdress.Text))
                {
                    MessageBox.Show("Please fill all values");
                }
                else
                {
                    conn.Open();
                    int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("Patient data saved successfully.");
                        btnRefresh_Click(this, new EventArgs());
                    }
                    else
                    {
                        MessageBox.Show("Error inserting patient data.");
                    }

                }
            }
        }



        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            string query = "SELECT * FROM Patient";

            SqlCommand command = new SqlCommand(query, conn);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridPatientList.DataSource = table;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);

            if (dataGridPatientList.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    int index = dataGridPatientList.SelectedRows[0].Index;
                    int patientID = Convert.ToInt32(dataGridPatientList.Rows[index].Cells["patient_id"].Value);

                    conn.Open();

                    string queryPatient = "DELETE FROM Patient WHERE patient_id = @patientID";
                    SqlCommand commandPatient = new SqlCommand(queryPatient, conn);
                    commandPatient.Parameters.AddWithValue("@patientID", patientID);
                    int ressult = commandPatient.ExecuteNonQuery();

                    if (ressult > 0)
                    {
                        MessageBox.Show("Row deleted successfully.");
                        dataGridPatientList.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("Error deleting row.");
                    }
                }
            }

            conn.Close();
        }





        private void Form2_Load(object sender, EventArgs e)
        {
            btnRefresh_Click(this, new EventArgs());
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridPatientList.SelectedRows.Count > 0)
            {
                string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
                SqlConnection conn = new SqlConnection(connString);
                {
                    int index = dataGridPatientList.SelectedRows[0].Index;
                    int patientID = Convert.ToInt32(dataGridPatientList.Rows[index].Cells["patient_id"].Value);
                    string query = "UPDATE Patient SET patient_name = @Value1, patient_gender = @Value2, patient_PhoneNumber = @Value4, adress = @Value5 WHERE patient_id = @patientID";

                    SqlCommand command = new SqlCommand(query, conn);

                    command.Parameters.AddWithValue("@patientID", patientID);
                    command.Parameters.AddWithValue("@Value1", txtPatientName.Text);
                    command.Parameters.AddWithValue("@Value2", comboBoxGender.Text);
                    command.Parameters.AddWithValue("@Value4", txtNumber.Text);
                    command.Parameters.AddWithValue("@Value5", txtboxAdress.Text);
                    if (string.IsNullOrEmpty(txtPatientName.Text) || string.IsNullOrEmpty(comboBoxGender.Text) || string.IsNullOrEmpty(txtNumber.Text) || string.IsNullOrEmpty(txtboxAdress.Text))
                    {
                        MessageBox.Show("Please fill all values");
                    }
                    else
                    {
                        conn.Open();
                        int result = command.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            btnRefresh_Click(this, new EventArgs());
                        }
                        else
                        {
                            MessageBox.Show("Error updating data.");
                        }
                    }
                }
            }

            else
            {
                MessageBox.Show("No row selected.");
            } 
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridPatientList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dateTimePickerPatient_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
            
  
    

