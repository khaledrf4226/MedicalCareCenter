﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project
{
    public partial class doctor : Form
    {
        public doctor()
        {
            InitializeComponent();
            RefreshDoctorGrid();
        }

       

        private void RefreshDoctorGrid()
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            string query = "SELECT * FROM doctor";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridViewDoctor.DataSource = table;
        }



        private void btnInfo_Click(object sender, EventArgs e)
        {
            this.Close();
            PatientInfo patientInfo = new PatientInfo();
            patientInfo.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            this.Close();
            Appointment appointment = new Appointment();
            appointment.Show();

        }

        private void txtDoctorName_TextChanged(object sender, EventArgs e)
        {

        }

        private void doctor_Load(object sender, EventArgs e)
        {
            RefreshDoctorGrid();
            

        }


        private void BtnDrDelete_Click(object sender, EventArgs e)
        {
           

            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);

            if (dataGridViewDoctor.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    int index = dataGridViewDoctor.SelectedRows[0].Index;
                    int doctorID = Convert.ToInt32(dataGridViewDoctor.Rows[index].Cells["doctor_id"].Value);

                    conn.Open();

                   
                    string queryDoctor = "DELETE FROM doctor WHERE doctor_id = @doctorID";
                    SqlCommand commandDoctor = new SqlCommand(queryDoctor, conn);
                    commandDoctor.Parameters.AddWithValue("@doctorID", doctorID);
                    int ressult = commandDoctor.ExecuteNonQuery();


                    if (ressult > 0)
                    {
                        MessageBox.Show("Row deleted successfully.");
                        dataGridViewDoctor.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("Error deleting row.");
                    }
                }
            }
        }

        private void btnEditDrInfo_Click(object sender, EventArgs e)
        {
            if (dataGridViewDoctor.SelectedRows.Count > 0)
            {
                string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    int index = dataGridViewDoctor.SelectedRows[0].Index;
                    int patientID = Convert.ToInt32(dataGridViewDoctor.Rows[index].Cells["doctor_id"].Value);

                    string query = "UPDATE doctor SET doctor_name = @Value1, doctor_major = @Value2, doctor_phone = @Value3 WHERE doctor_id = @doctorID";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@doctorID", patientID);
                        command.Parameters.AddWithValue("@Value1", txtDoctorName.Text);
                        command.Parameters.AddWithValue("@Value2", txtDoctorMajor.Text);
                        command.Parameters.AddWithValue("@Value3", txtphoneNumber.Text);
                        if (string.IsNullOrEmpty(txtDoctorName.Text) || string.IsNullOrEmpty(txtDoctorMajor.Text) || string.IsNullOrEmpty(txtphoneNumber.Text))
                        {
                            MessageBox.Show("Please fill all values");
                        }
                        else
                        {
                            conn.Open();
                            int result = command.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("Data updated successfully.");
                                RefreshDoctorGrid();
                            }
                            else
                            {
                                MessageBox.Show("Error updating data.");
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No row selected.");
            }

        }

        private void btnDrSave_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            string query = "INSERT INTO doctor ( doctor_name, doctor_major, doctor_phone) VALUES (@Value1, @Value2, @Value3)";

            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@Value1", txtDoctorName.Text);
            command.Parameters.AddWithValue("@Value2", txtDoctorMajor.Text);
            command.Parameters.AddWithValue("@Value3", txtphoneNumber.Text);
            if (string.IsNullOrEmpty(txtDoctorName.Text) || string.IsNullOrEmpty(txtDoctorMajor.Text) || string.IsNullOrEmpty(txtphoneNumber.Text))
            {
                MessageBox.Show("Please fill all values");
            }
            else
            {
                conn.Open();
                command.ExecuteNonQuery();
                conn.Close();
                RefreshDoctorGrid();
            }
        }

        private void btnDr_Click(object sender, EventArgs e)
        {
          
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 patient = new Form2();
            patient.Show();
        }
    }
}
    

