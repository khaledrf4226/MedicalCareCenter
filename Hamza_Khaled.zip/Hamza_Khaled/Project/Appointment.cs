﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Appointment : Form
    {
        public Appointment()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            Form2 patient = new Form2();
            patient.Show();
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDr_Click(object sender, EventArgs e)
        {
            this.Close();
            doctor dr = new doctor();
            dr.Show();
        }

        private void Appointment_Load(object sender, EventArgs e)
        {
            RefreshDoctorGrid();
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);

            string query = "SELECT doctor_id, doctor_name FROM doctor";
            SqlCommand command = new SqlCommand(query, conn);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            comboBox2.DataSource = table;
            comboBox2.DisplayMember = "doctor_name"; 
            comboBox2.ValueMember = "doctor_id";

            string query2 = "SELECT patient_id, patient_name FROM Patient";
            SqlCommand command2 = new SqlCommand(query2, conn);
            SqlDataAdapter adapter2 = new SqlDataAdapter(command2);
            DataTable table2 = new DataTable();
            adapter2.Fill(table2);

            comboBox1.DataSource = table2;
            comboBox1.DisplayMember = "patient_name"; 
            comboBox1.ValueMember = "patient_id";
          

        }

        private void btnDrSave_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
                int doctorID = Convert.ToInt32(comboBox2.SelectedValue);
            int patientID = Convert.ToInt32(comboBox2.SelectedValue);
            string query = "INSERT INTO appointment (patient_id, doctor_id, appointment_date) VALUES (@patientID, @doctorID, @Value3)";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@patientID", patientID);
            command.Parameters.AddWithValue("@doctorID", doctorID);
            DateTime dateTimeValue = dateTimePicker1.Value;
            command.Parameters.AddWithValue("@Value3", dateTimeValue);
            conn.Open();
            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Patient data saved successfully.");
                RefreshDoctorGrid();
            }
            else
            {
                MessageBox.Show("Error inserting patient data.");
            }
        }

        private void dataGridiewAppointment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void RefreshDoctorGrid()
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            string query = "SELECT * FROM appointment";
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridiewAppointment.DataSource = table;
        }

        private void btnEditAppInfo_Click(object sender, EventArgs e)
        {
            if (dataGridiewAppointment.SelectedRows.Count > 0)
            {
                string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    int index = dataGridiewAppointment.SelectedRows[0].Index;
                    int appointmentID = Convert.ToInt32(dataGridiewAppointment.Rows[index].Cells["appointment_id"].Value); 
                    int doctorID = Convert.ToInt32(comboBox2.SelectedValue);
                    int patientID = Convert.ToInt32(comboBox2.SelectedValue);
                    string query = "UPDATE appointment SET appointment_date = @Value1, patient_id = @Value2, doctor_id = @Value3 WHERE appointment_id = @appointmentID";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@appointmentID", appointmentID);
                        command.Parameters.AddWithValue("@Value2", patientID);
                        DateTime dateTimeValue = dateTimePicker1.Value;
                         command.Parameters.AddWithValue("@Value1", dateTimeValue);
                        command.Parameters.AddWithValue("@Value3", doctorID);

                        conn.Open();
                        int result = command.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Data updated successfully.");
                            RefreshDoctorGrid();
                        }
                        else
                        {
                            MessageBox.Show("Error updating data.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No row selected.");
            }
        }

        private void BtnAppDelete_Click(object sender, EventArgs e)
        {
            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);

            if (dataGridiewAppointment.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    int index = dataGridiewAppointment.SelectedRows[0].Index;
                    int appointmentID = Convert.ToInt32(dataGridiewAppointment.Rows[index].Cells["appointment_id"].Value);

                    conn.Open();

                    string queryPatient = "DELETE FROM appointment WHERE appointment_id = @appointmentID";
                    SqlCommand commandPatient = new SqlCommand(queryPatient, conn);
                    commandPatient.Parameters.AddWithValue("@appointmentID", appointmentID);
                    int ressult = commandPatient.ExecuteNonQuery();

                    if (ressult > 0)
                    {
                        MessageBox.Show("Row deleted successfully.");
                        dataGridiewAppointment.Rows.RemoveAt(index);
                    }
                    else
                    {
                        MessageBox.Show("Error deleting row.");
                    }
                }
            }

            conn.Close();
        }
    }
}
