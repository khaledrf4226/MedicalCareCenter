﻿namespace Project
{
    partial class doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(doctor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.btnInfo = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnDr = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnAppointment = new System.Windows.Forms.Button();
            this.Patient = new System.Windows.Forms.Label();
            this.btnPatient = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.edit = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnDrDelete = new System.Windows.Forms.Button();
            this.btnEditDrInfo = new System.Windows.Forms.Button();
            this.btnDrSave = new System.Windows.Forms.Button();
            this.txtphoneNumber = new System.Windows.Forms.TextBox();
            this.txtDoctorMajor = new System.Windows.Forms.TextBox();
            this.txtDoctorName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewDoctor = new System.Windows.Forms.DataGridView();
            this.doctorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet1 = new Project.ProjectDataSet1();
            this.label3 = new System.Windows.Forms.Label();
            this.doctorTableAdapter = new Project.ProjectDataSet1TableAdapters.doctorTableAdapter();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDoctor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.btnInfo);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.btnDr);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.btnAppointment);
            this.panel1.Controls.Add(this.Patient);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 966);
            this.panel1.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(35, 811);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 20);
            this.label16.TabIndex = 14;
            this.label16.Text = "log out";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(14, 696);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 82);
            this.button2.TabIndex = 13;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(26, 649);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 20);
            this.label15.TabIndex = 12;
            this.label15.Text = "patient info";
            // 
            // btnInfo
            // 
            this.btnInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnInfo.Image")));
            this.btnInfo.Location = new System.Drawing.Point(15, 535);
            this.btnInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(104, 85);
            this.btnInfo.TabIndex = 11;
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(34, 482);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "Doctors";
            // 
            // btnDr
            // 
            this.btnDr.Image = ((System.Drawing.Image)(resources.GetObject("btnDr.Image")));
            this.btnDr.Location = new System.Drawing.Point(14, 364);
            this.btnDr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDr.Name = "btnDr";
            this.btnDr.Size = new System.Drawing.Size(104, 88);
            this.btnDr.TabIndex = 9;
            this.btnDr.UseVisualStyleBackColor = true;
            this.btnDr.Click += new System.EventHandler(this.btnDr_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(26, 309);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 20);
            this.label13.TabIndex = 8;
            this.label13.Text = "Appointment";
            // 
            // btnAppointment
            // 
            this.btnAppointment.AccessibleName = "btnAppointment";
            this.btnAppointment.Image = ((System.Drawing.Image)(resources.GetObject("btnAppointment.Image")));
            this.btnAppointment.Location = new System.Drawing.Point(15, 219);
            this.btnAppointment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointment.Name = "btnAppointment";
            this.btnAppointment.Size = new System.Drawing.Size(104, 72);
            this.btnAppointment.TabIndex = 7;
            this.btnAppointment.UseVisualStyleBackColor = true;
            this.btnAppointment.Click += new System.EventHandler(this.btnAppointment_Click);
            // 
            // Patient
            // 
            this.Patient.AutoSize = true;
            this.Patient.BackColor = System.Drawing.Color.White;
            this.Patient.Location = new System.Drawing.Point(34, 161);
            this.Patient.Name = "Patient";
            this.Patient.Size = new System.Drawing.Size(59, 20);
            this.Patient.TabIndex = 6;
            this.Patient.Text = "Patient";
            // 
            // btnPatient
            // 
            this.btnPatient.AccessibleName = "btnPatient";
            this.btnPatient.Image = ((System.Drawing.Image)(resources.GetObject("btnPatient.Image")));
            this.btnPatient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPatient.Location = new System.Drawing.Point(14, 45);
            this.btnPatient.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(105, 98);
            this.btnPatient.TabIndex = 2;
            this.btnPatient.UseVisualStyleBackColor = true;
            this.btnPatient.Click += new System.EventHandler(this.btnPatient_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.edit);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.BtnDrDelete);
            this.panel2.Controls.Add(this.btnEditDrInfo);
            this.panel2.Controls.Add(this.btnDrSave);
            this.panel2.Controls.Add(this.txtphoneNumber);
            this.panel2.Controls.Add(this.txtDoctorMajor);
            this.panel2.Controls.Add(this.txtDoctorName);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(177, 32);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1134, 419);
            this.panel2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(716, 331);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "delete";
            // 
            // edit
            // 
            this.edit.AutoSize = true;
            this.edit.BackColor = System.Drawing.Color.White;
            this.edit.ForeColor = System.Drawing.Color.Black;
            this.edit.Location = new System.Drawing.Point(716, 212);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(65, 20);
            this.edit.TabIndex = 7;
            this.edit.Text = "edit info";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(716, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Save";
            // 
            // BtnDrDelete
            // 
            this.BtnDrDelete.Image = ((System.Drawing.Image)(resources.GetObject("BtnDrDelete.Image")));
            this.BtnDrDelete.Location = new System.Drawing.Point(612, 307);
            this.BtnDrDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnDrDelete.Name = "BtnDrDelete";
            this.BtnDrDelete.Size = new System.Drawing.Size(84, 68);
            this.BtnDrDelete.TabIndex = 3;
            this.BtnDrDelete.UseVisualStyleBackColor = true;
            this.BtnDrDelete.Click += new System.EventHandler(this.BtnDrDelete_Click);
            // 
            // btnEditDrInfo
            // 
            this.btnEditDrInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnEditDrInfo.Image")));
            this.btnEditDrInfo.Location = new System.Drawing.Point(603, 182);
            this.btnEditDrInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnEditDrInfo.Name = "btnEditDrInfo";
            this.btnEditDrInfo.Size = new System.Drawing.Size(84, 75);
            this.btnEditDrInfo.TabIndex = 2;
            this.btnEditDrInfo.UseVisualStyleBackColor = true;
            this.btnEditDrInfo.Click += new System.EventHandler(this.btnEditDrInfo_Click);
            // 
            // btnDrSave
            // 
            this.btnDrSave.Image = ((System.Drawing.Image)(resources.GetObject("btnDrSave.Image")));
            this.btnDrSave.Location = new System.Drawing.Point(588, 80);
            this.btnDrSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDrSave.Name = "btnDrSave";
            this.btnDrSave.Size = new System.Drawing.Size(84, 64);
            this.btnDrSave.TabIndex = 2;
            this.btnDrSave.UseVisualStyleBackColor = true;
            this.btnDrSave.Click += new System.EventHandler(this.btnDrSave_Click);
            // 
            // txtphoneNumber
            // 
            this.txtphoneNumber.Location = new System.Drawing.Point(216, 300);
            this.txtphoneNumber.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtphoneNumber.Multiline = true;
            this.txtphoneNumber.Name = "txtphoneNumber";
            this.txtphoneNumber.Size = new System.Drawing.Size(209, 33);
            this.txtphoneNumber.TabIndex = 1;
            // 
            // txtDoctorMajor
            // 
            this.txtDoctorMajor.Location = new System.Drawing.Point(216, 182);
            this.txtDoctorMajor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDoctorMajor.Multiline = true;
            this.txtDoctorMajor.Name = "txtDoctorMajor";
            this.txtDoctorMajor.Size = new System.Drawing.Size(209, 33);
            this.txtDoctorMajor.TabIndex = 1;
            // 
            // txtDoctorName
            // 
            this.txtDoctorName.Location = new System.Drawing.Point(216, 80);
            this.txtDoctorName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDoctorName.Multiline = true;
            this.txtDoctorName.Name = "txtDoctorName";
            this.txtDoctorName.Size = new System.Drawing.Size(209, 33);
            this.txtDoctorName.TabIndex = 1;
            this.txtDoctorName.TextChanged += new System.EventHandler(this.txtDoctorName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 294);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 39);
            this.label4.TabIndex = 0;
            this.label4.Text = "Phone number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 39);
            this.label2.TabIndex = 0;
            this.label2.Text = "Doctor Major";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Doctor name";
            // 
            // dataGridViewDoctor
            // 
            this.dataGridViewDoctor.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewDoctor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDoctor.GridColor = System.Drawing.Color.Gray;
            this.dataGridViewDoctor.Location = new System.Drawing.Point(177, 482);
            this.dataGridViewDoctor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewDoctor.Name = "dataGridViewDoctor";
            this.dataGridViewDoctor.RowHeadersWidth = 51;
            this.dataGridViewDoctor.RowTemplate.Height = 24;
            this.dataGridViewDoctor.Size = new System.Drawing.Size(1134, 469);
            this.dataGridViewDoctor.TabIndex = 2;
            // 
            // doctorBindingSource
            // 
            this.doctorBindingSource.DataMember = "doctor";
            this.doctorBindingSource.DataSource = this.projectDataSet1;
            // 
            // projectDataSet1
            // 
            this.projectDataSet1.DataSetName = "ProjectDataSet1";
            this.projectDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(686, 439);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 39);
            this.label3.TabIndex = 3;
            this.label3.Text = "Doctor list ";
            // 
            // doctorTableAdapter
            // 
            this.doctorTableAdapter.ClearBeforeFill = true;
            // 
            // doctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1324, 966);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridViewDoctor);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "doctor";
            this.Text = "doctor";
            this.Load += new System.EventHandler(this.doctor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDoctor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtDoctorMajor;
        private System.Windows.Forms.TextBox txtDoctorName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Label Patient;
        private System.Windows.Forms.Button btnAppointment;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnDr;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button BtnDrDelete;
        private System.Windows.Forms.Button btnDrSave;
        private System.Windows.Forms.TextBox txtphoneNumber;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridViewDoctor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnEditDrInfo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label edit;
        private System.Windows.Forms.Label label6;
        private ProjectDataSet1 projectDataSet1;
        private System.Windows.Forms.BindingSource doctorBindingSource;
        private ProjectDataSet1TableAdapters.doctorTableAdapter doctorTableAdapter;
    }
}