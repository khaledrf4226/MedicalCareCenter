﻿namespace Project
{
    partial class Appointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appointment));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.btnInfo = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnDr = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnAppointment = new System.Windows.Forms.Button();
            this.Patient = new System.Windows.Forms.Label();
            this.btnPatient = new System.Windows.Forms.Button();
            this.dataGridiewAppointment = new System.Windows.Forms.DataGridView();
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new Project.DataSet1();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnEditAppInfo = new System.Windows.Forms.Button();
            this.BtnAppDelete = new System.Windows.Forms.Button();
            this.btnappointmentSave = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridiewAppointment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.btnInfo);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.btnDr);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.btnAppointment);
            this.panel1.Controls.Add(this.Patient);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(158, 976);
            this.panel1.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(35, 811);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 20);
            this.label16.TabIndex = 14;
            this.label16.Text = "log out";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(14, 696);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 82);
            this.button2.TabIndex = 13;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(26, 649);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 20);
            this.label15.TabIndex = 12;
            this.label15.Text = "patient info";
            // 
            // btnInfo
            // 
            this.btnInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnInfo.Image")));
            this.btnInfo.Location = new System.Drawing.Point(15, 535);
            this.btnInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(104, 85);
            this.btnInfo.TabIndex = 11;
            this.btnInfo.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(34, 482);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "Doctors";
            // 
            // btnDr
            // 
            this.btnDr.Image = ((System.Drawing.Image)(resources.GetObject("btnDr.Image")));
            this.btnDr.Location = new System.Drawing.Point(14, 364);
            this.btnDr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDr.Name = "btnDr";
            this.btnDr.Size = new System.Drawing.Size(104, 88);
            this.btnDr.TabIndex = 9;
            this.btnDr.UseVisualStyleBackColor = true;
            this.btnDr.Click += new System.EventHandler(this.btnDr_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(26, 309);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 20);
            this.label13.TabIndex = 8;
            this.label13.Text = "Appointment";
            // 
            // btnAppointment
            // 
            this.btnAppointment.AccessibleName = "btnAppointment";
            this.btnAppointment.Image = ((System.Drawing.Image)(resources.GetObject("btnAppointment.Image")));
            this.btnAppointment.Location = new System.Drawing.Point(15, 219);
            this.btnAppointment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointment.Name = "btnAppointment";
            this.btnAppointment.Size = new System.Drawing.Size(104, 72);
            this.btnAppointment.TabIndex = 7;
            this.btnAppointment.UseVisualStyleBackColor = true;
            this.btnAppointment.Click += new System.EventHandler(this.btnAppointment_Click);
            // 
            // Patient
            // 
            this.Patient.AutoSize = true;
            this.Patient.BackColor = System.Drawing.Color.White;
            this.Patient.Location = new System.Drawing.Point(34, 161);
            this.Patient.Name = "Patient";
            this.Patient.Size = new System.Drawing.Size(59, 20);
            this.Patient.TabIndex = 6;
            this.Patient.Text = "Patient";
            // 
            // btnPatient
            // 
            this.btnPatient.AccessibleName = "btnPatient";
            this.btnPatient.Image = ((System.Drawing.Image)(resources.GetObject("btnPatient.Image")));
            this.btnPatient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPatient.Location = new System.Drawing.Point(14, 45);
            this.btnPatient.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(105, 98);
            this.btnPatient.TabIndex = 2;
            this.btnPatient.UseVisualStyleBackColor = true;
            this.btnPatient.Click += new System.EventHandler(this.btnPatient_Click);
            // 
            // dataGridiewAppointment
            // 
            this.dataGridiewAppointment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridiewAppointment.Location = new System.Drawing.Point(164, 438);
            this.dataGridiewAppointment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridiewAppointment.Name = "dataGridiewAppointment";
            this.dataGridiewAppointment.RowHeadersWidth = 51;
            this.dataGridiewAppointment.RowTemplate.Height = 24;
            this.dataGridiewAppointment.Size = new System.Drawing.Size(1272, 446);
            this.dataGridiewAppointment.TabIndex = 3;
            this.dataGridiewAppointment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridiewAppointment_CellContentClick);
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.dataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btnEditAppInfo);
            this.panel2.Controls.Add(this.BtnAppDelete);
            this.panel2.Controls.Add(this.btnappointmentSave);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(192, 32);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1259, 398);
            this.panel2.TabIndex = 4;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(304, 137);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(159, 28);
            this.comboBox2.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(101, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 39);
            this.label1.TabIndex = 15;
            this.label1.Text = "choose doctor";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(304, 61);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(159, 28);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(101, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(191, 39);
            this.label7.TabIndex = 13;
            this.label7.Text = "choose patient";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(834, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 39);
            this.label6.TabIndex = 8;
            this.label6.Text = "delete";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(834, 184);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 39);
            this.label5.TabIndex = 7;
            this.label5.Text = "edit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(834, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 39);
            this.label4.TabIndex = 6;
            this.label4.Text = "add";
            // 
            // btnEditAppInfo
            // 
            this.btnEditAppInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnEditAppInfo.Image")));
            this.btnEditAppInfo.Location = new System.Drawing.Point(731, 148);
            this.btnEditAppInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnEditAppInfo.Name = "btnEditAppInfo";
            this.btnEditAppInfo.Size = new System.Drawing.Size(84, 75);
            this.btnEditAppInfo.TabIndex = 5;
            this.btnEditAppInfo.UseVisualStyleBackColor = true;
            this.btnEditAppInfo.Click += new System.EventHandler(this.btnEditAppInfo_Click);
            // 
            // BtnAppDelete
            // 
            this.BtnAppDelete.Image = ((System.Drawing.Image)(resources.GetObject("BtnAppDelete.Image")));
            this.BtnAppDelete.Location = new System.Drawing.Point(731, 252);
            this.BtnAppDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAppDelete.Name = "BtnAppDelete";
            this.BtnAppDelete.Size = new System.Drawing.Size(84, 68);
            this.BtnAppDelete.TabIndex = 4;
            this.BtnAppDelete.UseVisualStyleBackColor = true;
            this.BtnAppDelete.Click += new System.EventHandler(this.BtnAppDelete_Click);
            // 
            // btnappointmentSave
            // 
            this.btnappointmentSave.Image = ((System.Drawing.Image)(resources.GetObject("btnappointmentSave.Image")));
            this.btnappointmentSave.Location = new System.Drawing.Point(731, 51);
            this.btnappointmentSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnappointmentSave.Name = "btnappointmentSave";
            this.btnappointmentSave.Size = new System.Drawing.Size(84, 64);
            this.btnappointmentSave.TabIndex = 3;
            this.btnappointmentSave.UseVisualStyleBackColor = true;
            this.btnappointmentSave.Click += new System.EventHandler(this.btnDrSave_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(340, 252);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(184, 26);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(86, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 39);
            this.label3.TabIndex = 0;
            this.label3.Text = " Apointment Date";
            // 
            // Appointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1583, 976);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridiewAppointment);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Appointment";
            this.Text = "Appointment";
            this.Load += new System.EventHandler(this.Appointment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridiewAppointment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnDr;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnAppointment;
        private System.Windows.Forms.Label Patient;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.DataGridView dataGridiewAppointment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnappointmentSave;
        private System.Windows.Forms.Button BtnAppDelete;
        private System.Windows.Forms.Button btnEditAppInfo;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private DataSet1 dataSet1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label7;
    }
}