﻿namespace Project
{
    partial class PatientInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PatientInfo));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.btnInfo = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.btnDr = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.btnAppointment = new System.Windows.Forms.Button();
            this.Patient = new System.Windows.Forms.Label();
            this.btnPatient = new System.Windows.Forms.Button();
            this.dataGridViewPatientInfo = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatientInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.btnInfo);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.btnDr);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.btnAppointment);
            this.panel1.Controls.Add(this.Patient);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 1029);
            this.panel1.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(35, 811);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 20);
            this.label16.TabIndex = 14;
            this.label16.Text = "log out";
            // 
            // button2
            // 
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(14, 696);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 82);
            this.button2.TabIndex = 13;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(26, 649);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 20);
            this.label15.TabIndex = 12;
            this.label15.Text = "patient info";
            // 
            // btnInfo
            // 
            this.btnInfo.Image = ((System.Drawing.Image)(resources.GetObject("btnInfo.Image")));
            this.btnInfo.Location = new System.Drawing.Point(15, 535);
            this.btnInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(104, 85);
            this.btnInfo.TabIndex = 11;
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(34, 482);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "Doctors";
            // 
            // btnDr
            // 
            this.btnDr.Image = ((System.Drawing.Image)(resources.GetObject("btnDr.Image")));
            this.btnDr.Location = new System.Drawing.Point(14, 364);
            this.btnDr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDr.Name = "btnDr";
            this.btnDr.Size = new System.Drawing.Size(104, 88);
            this.btnDr.TabIndex = 9;
            this.btnDr.UseVisualStyleBackColor = true;
            this.btnDr.Click += new System.EventHandler(this.btnDr_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(26, 309);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 20);
            this.label13.TabIndex = 8;
            this.label13.Text = "Appointment";
            // 
            // btnAppointment
            // 
            this.btnAppointment.AccessibleName = "btnAppointment";
            this.btnAppointment.Image = ((System.Drawing.Image)(resources.GetObject("btnAppointment.Image")));
            this.btnAppointment.Location = new System.Drawing.Point(15, 219);
            this.btnAppointment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointment.Name = "btnAppointment";
            this.btnAppointment.Size = new System.Drawing.Size(104, 72);
            this.btnAppointment.TabIndex = 7;
            this.btnAppointment.UseVisualStyleBackColor = true;
            this.btnAppointment.Click += new System.EventHandler(this.btnAppointment_Click);
            // 
            // Patient
            // 
            this.Patient.AutoSize = true;
            this.Patient.BackColor = System.Drawing.Color.White;
            this.Patient.Location = new System.Drawing.Point(34, 161);
            this.Patient.Name = "Patient";
            this.Patient.Size = new System.Drawing.Size(59, 20);
            this.Patient.TabIndex = 6;
            this.Patient.Text = "Patient";
            // 
            // btnPatient
            // 
            this.btnPatient.AccessibleName = "btnPatient";
            this.btnPatient.Image = ((System.Drawing.Image)(resources.GetObject("btnPatient.Image")));
            this.btnPatient.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPatient.Location = new System.Drawing.Point(14, 45);
            this.btnPatient.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(105, 98);
            this.btnPatient.TabIndex = 2;
            this.btnPatient.UseVisualStyleBackColor = true;
            this.btnPatient.Click += new System.EventHandler(this.btnPatient_Click);
            // 
            // dataGridViewPatientInfo
            // 
            this.dataGridViewPatientInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPatientInfo.Location = new System.Drawing.Point(185, 55);
            this.dataGridViewPatientInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewPatientInfo.Name = "dataGridViewPatientInfo";
            this.dataGridViewPatientInfo.RowHeadersWidth = 51;
            this.dataGridViewPatientInfo.RowTemplate.Height = 24;
            this.dataGridViewPatientInfo.Size = new System.Drawing.Size(987, 723);
            this.dataGridViewPatientInfo.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sans Serif Collection", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(746, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "Patient Info";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.Location = new System.Drawing.Point(1205, 324);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(105, 98);
            this.btnRefresh.TabIndex = 4;
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // PatientInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1629, 1029);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewPatientInfo);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PatientInfo";
            this.Text = "PatientInfo";
            this.Load += new System.EventHandler(this.PatientInfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPatientInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnDr;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnAppointment;
        private System.Windows.Forms.Label Patient;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.DataGridView dataGridViewPatientInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRefresh;
    }
}