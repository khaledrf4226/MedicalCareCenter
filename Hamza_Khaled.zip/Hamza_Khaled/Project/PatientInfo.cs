﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class PatientInfo : Form
    {
        public PatientInfo()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            this.Close();
            PatientInfo patientInfo = new PatientInfo();
            patientInfo.Show();
        }

        private void btnDr_Click(object sender, EventArgs e)
        {
            this.Close();
            doctor dr = new doctor();
            dr.Show();
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            this.Close();
            Appointment appointment = new Appointment();
            appointment.Show();
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 patient = new Form2();
            patient.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {

            string connString = @"Data Source=DESKTOP-7OITMRT\SQLEXPRESS;Initial Catalog=project1;Integrated Security=true";
            SqlConnection conn = new SqlConnection(connString);
            string query = "SELECT * FROM Patient";
            
                SqlCommand command = new SqlCommand(query, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridViewPatientInfo.DataSource = table;
            }

        private void PatientInfo_Load(object sender, EventArgs e)
        {

        }
    }
    }

